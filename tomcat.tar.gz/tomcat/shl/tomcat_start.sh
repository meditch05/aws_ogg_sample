#!/bin/bash

/home/ec2-user/tomcat/servers/aws_test/shl/start.sh; sleep 3;

### check_web.sh after start
check_web.sh

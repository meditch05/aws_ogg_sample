#!/bin/bash

/dbawork/tomcat/servers/aws_test/shl/stop.sh;  sleep 3;


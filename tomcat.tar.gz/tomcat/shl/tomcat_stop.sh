#!/bin/bash

/home/ec2-user/tomcat/servers/aws_test/shl/stop.sh;  sleep 3;


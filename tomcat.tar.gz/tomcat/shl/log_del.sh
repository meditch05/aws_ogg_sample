#!/bin/bash

################################
# Tomcat
################################
SERVERS="aws_test "

for SERVER_NAME in ${SERVERS}
do
   # gzip tomcat log over 5 days
   find /dbawork/tomcat/servers/${SERVER_NAME} -type f -name "catalina.out-*[0-9]"       -mtime +5  -exec gzip -9 {} \;
   find /dbawork/tomcat/servers/${SERVER_NAME} -type f -name "catalina.*.log"            -mtime +5  -exec gzip -9 {} \;
   find /dbawork/tomcat/servers/${SERVER_NAME} -type f -name "localhost_access.*.log"    -mtime +5  -exec gzip -9 {} \;
   find /dbawork/tomcat/servers/${SERVER_NAME} -type f -name "localhost.*.log"           -mtime +5  -exec gzip -9 {} \;
   find /dbawork/tomcat/servers/${SERVER_NAME} -type f -name "manager.*.log"             -mtime +5  -exec gzip -9 {} \;
   find /dbawork/tomcat/servers/${SERVER_NAME} -type f -name "host-manager.*.log"        -mtime +5  -exec gzip -9 {} \;
   find /dbawork/tomcat/servers/${SERVER_NAME} -type f -name "gc_*.log"                  -mtime +5  -exec gzip -9 {} \;

   # del tomcat log over 170 days
   find /dbawork/tomcat/servers/${SERVER_NAME} -type f -name "catalina.out-*[0-9].gz"    -mtime +170 -exec rm -rf  {} \;
   find /dbawork/tomcat/servers/${SERVER_NAME} -type f -name "localhost_access.*.log.gz" -mtime +170 -exec rm -rf  {} \;
   find /dbawork/tomcat/servers/${SERVER_NAME} -type f -name "localhost.*.log.gz"        -mtime +170 -exec rm -rf  {} \;
   find /dbawork/tomcat/servers/${SERVER_NAME} -type f -name "catalina.*.log"            -mtime +170 -exec rm -rf  {} \;
   find /dbawork/tomcat/servers/${SERVER_NAME} -type f -name "manager.*.log.gz"          -mtime +170 -exec rm -rf  {} \;
   find /dbawork/tomcat/servers/${SERVER_NAME} -type f -name "host-manager.*.log.gz"     -mtime +170 -exec rm -rf  {} \;
   find /dbawork/tomcat/servers/${SERVER_NAME} -type f -name "gc_*.log.gz"               -mtime +170 -exec rm -rf  {} \;
done

#chmod log dir, files
find /dbawork/tomcat/servers -type d -exec chmod 750 {} \;
find /dbawork/tomcat/servers -type f -exec chmod 640 {} \;
